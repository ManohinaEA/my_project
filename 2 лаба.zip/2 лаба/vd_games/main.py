def main():
    print("VD Games running")

if __name__ == "__main__":
    main()
